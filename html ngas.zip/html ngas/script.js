const form = document.getElementById('download-form');
const videoUrlInput = document.getElementById('video-url');
const statusDiv = document.getElementById('status');

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const videoUrl = videoUrlInput.value.trim();

    if (!videoUrl) {
        statusDiv.textContent = 'Please enter a valid YouTube video URL';
        return;
    }

    try {
        const response = await fetch('/download', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ videoUrl })
        });

        if (!response.ok) {
            const errorData = await response.json();
            statusDiv.textContent = `Error downloading video: ${errorData.error || 'Unknown error'}`;
            return;
        }

        const data = await response.json();
        if (data.success) {
            statusDiv.textContent = 'Video downloaded successfully!';
        } else {
            statusDiv.textContent = `Error downloading video: ${data.error || 'Unknown error'}`;
        }
    } catch (err) {
        statusDiv.textContent = `Error downloading video: ${err.message}`;
    }
});
