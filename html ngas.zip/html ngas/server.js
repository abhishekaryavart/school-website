const express = require('express');
const app = express();
const youtubeDl = require('youtube-dl');

app.use(express.json());

app.post('/download', (req, res) => {
    const videoUrl = req.body.videoUrl;

    if (!videoUrl) {
        return res.status(400).json({ success: false, error: 'Video URL is required.' });
    }

    const options = {
        format: 'mp4',
        quality: 'highest'
    };

    youtubeDl.exec(videoUrl, options, (err, output) => {
        if (err) {
            console.error('Download error:', err);
            return res.status(500).json({ success: false, error: err.message });
        }
        
        console.log('Download output:', output);
        res.json({ success: true });
    });
});

app.listen(3000, () => {
    console.log('Server listening on port 3000');
});
